<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json");

error_reporting(E_ALL);
ini_set("display_errors", 1);

require_once "db.php";
require_once "vendor/autoload.php";
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

$secret_key = "mi_clave_secreta";

try {
    if (!isset($_COOKIE['auth_token'])) {
        throw new Exception("No autenticado");
    }

    $decoded = JWT::decode($_COOKIE['auth_token'], new Key($secret_key, 'HS256'));

    if (!isset($decoded->doctor_id)) {
        throw new Exception("doctor_id no presente en el token");
    }

    $doctor_id = intval($decoded->doctor_id);

    $sql = "SELECT a.id, a.fecha, a.hora, a.estado, a.motivo, a.paciente_id, a.doctor_id, p.nombre AS paciente
        FROM appointments a
        JOIN pacientes p ON a.paciente_id = p.id
        WHERE a.doctor_id = ?
        ORDER BY a.fecha DESC, a.hora ASC";


    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Error preparando SQL: " . $conn->error);
    }

    $stmt->bind_param("i", $doctor_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $citas = [];
    while ($row = $result->fetch_assoc()) {
        $citas[] = $row;
    }

    echo json_encode(["success" => true, "appointments" => $citas]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}
