<?php
require_once "db.php";
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

try {
    $stmt = $conn->prepare("SELECT * FROM catalogo_servicios ORDER BY categoria, subcategoria, nombre");
    $stmt->execute();
    $res = $stmt->get_result();

    $catalogo = [];
    while ($row = $res->fetch_assoc()) {
        $categoria = $row["categoria"];
        $subcategoria = $row["subcategoria"];

        if (!isset($catalogo[$categoria])) {
            $catalogo[$categoria] = [];
        }

        if (!isset($catalogo[$categoria][$subcategoria])) {
            $catalogo[$categoria][$subcategoria] = [];
        }

        $catalogo[$categoria][$subcategoria][] = [
            "id" => $row["id"],
            "nombre" => $row["nombre"],
            "precio" => $row["precio"]
        ];
    }

    echo json_encode(["success" => true, "catalogo" => $catalogo]);
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Error al obtener catálogo"]);
}
?>
