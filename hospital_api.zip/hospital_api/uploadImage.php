<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, X-Requested-With");
header("Access-Control-Allow-Credentials: true");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Obtener el tipo desde el query param
$tipo = isset($_GET['tipo']) ? basename($_GET['tipo']) : "otros";

// Crear subcarpeta por tipo
$targetDir = __DIR__ . "/uploads/$tipo/";
$publicUrlBase = "http://localhost/hospital_api/uploads/$tipo/";

// Crear carpeta si no existe
if (!file_exists($targetDir)) {
    if (!mkdir($targetDir, 0777, true)) {
        echo json_encode(["success" => false, "message" => "No se pudo crear la carpeta de destino."]);
        exit;
    }
}

if (!isset($_FILES['file'])) {
    echo json_encode(["success" => false, "message" => "No se recibió archivo."]);
    exit;
}

$file = $_FILES['file'];

if ($file['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(["success" => false, "message" => "Error al recibir el archivo: Código " . $file['error']]);
    exit;
}

$filename = basename($file['name']);
$uniqueName = uniqid() . "_" . $filename;
$targetFile = $targetDir . $uniqueName;

// Intentar mover el archivo
if (move_uploaded_file($file['tmp_name'], $targetFile)) {
    echo json_encode(["success" => true, "url" => $publicUrlBase . $uniqueName]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Error al mover el archivo.",
        "debug" => [
            "tmp_name" => $file['tmp_name'],
            "targetFile" => $targetFile,
            "is_writable_target" => is_writable(dirname($targetFile)),
        ]
    ]);
}
?>
