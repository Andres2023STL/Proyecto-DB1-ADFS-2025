<?php
require_once "db.php";
require_once "vendor/autoload.php";
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json");

$secret_key = "mi_clave_secreta";
if (!isset($_COOKIE['auth_token'])) {
    echo json_encode(["success" => false, "message" => "No autenticado"]);
    exit;
}

try {
    $decoded = JWT::decode($_COOKIE['auth_token'], new Key($secret_key, 'HS256'));
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Token inválido"]);
    exit;
}

// Obtener datos
$data = json_decode(file_get_contents("php://input"), true);

// Casteo seguro
$doctor_id = (int) $data['doctor_id'];
$paciente_id = (int) $data['paciente_id'];
$fecha = $data['fecha'];
$hora = $data['hora'];
$motivo = $data['motivo'] ?? '';
$asegurado = isset($data['asegurado']) && $data['asegurado'] ? 1 : 0;

// Validar existencia del paciente
$stmt = $conn->prepare("SELECT id FROM pacientes WHERE id = ?");
$stmt->bind_param("i", $paciente_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    echo json_encode(["success" => false, "message" => "Paciente no encontrado"]);
    exit;
}

// Insertar cita
$query = "INSERT INTO appointments (doctor_id, paciente_id, fecha, hora, motivo, asegurado) 
          VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("iisssi", $doctor_id, $paciente_id, $fecha, $hora, $motivo, $asegurado);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Cita guardada"]);
} else {
    echo json_encode(["success" => false, "message" => "Error al guardar cita"]);
}
