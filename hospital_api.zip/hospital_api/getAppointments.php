<?php
require_once "db.php";
require_once "vendor/autoload.php";
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

// CORS headers
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json");

// Validar token
$secret_key = "mi_clave_secreta";
if (!isset($_COOKIE['auth_token'])) {
    echo json_encode(["success" => false, "message" => "No autenticado"]);
    exit;
}

try {
    $decoded = JWT::decode($_COOKIE['auth_token'], new Key($secret_key, 'HS256'));
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Token inválido", "error" => $e->getMessage()]);
    exit;
}

// Obtener fecha desde el query param
$fecha = $_GET['date'] ?? null;
if (!$fecha) {
    echo json_encode(["success" => false, "message" => "Fecha no especificada"]);
    exit;
}

$sql = "SELECT a.id, a.hora, a.motivo, a.asegurado, 
               p.nombre AS paciente,
               u.name AS doctor_name
        FROM appointments a
        JOIN pacientes p ON a.paciente_id = p.id
        JOIN doctors d ON a.doctor_id = d.id
        JOIN users u ON d.user_id = u.id
        WHERE a.fecha = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $fecha);

if ($stmt->execute()) {
    $result = $stmt->get_result();
    $appointments = [];

    while ($row = $result->fetch_assoc()) {
        $appointments[] = $row;
    }

    echo json_encode(["success" => true, "appointments" => $appointments]);
} else {
    echo json_encode(["success" => false, "message" => "Error al obtener citas"]);
}
