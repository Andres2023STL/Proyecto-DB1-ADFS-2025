<?php
header('Content-Type: application/json');
include 'db_connection.php'; // Asegúrate que esta conexión funciona correctamente

$data = json_decode(file_get_contents('php://input'), true);

$name = $data['name'] ?? null;
$documentId = $data['documentId'] ?? null;
$insuranceNumber = $data['insuranceNumber'] ?? null;
$policyPercentage = $data['policy'] ?? null;
$expirationDate = $data['expirationDate'] ?? null;

if (!$name || !$documentId || !$insuranceNumber || !$policyPercentage || !$expirationDate) {
    echo json_encode(['success' => false, 'message' => 'Faltan campos requeridos']);
    exit;
}

$conn->begin_transaction();

try {
    // Insertar cliente
    $stmt = $conn->prepare("INSERT INTO insurance_clients (name, document_id, insurance_number) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $documentId, $insuranceNumber);
    $stmt->execute();
    $clientId = $stmt->insert_id;

    // Insertar póliza
    $stmt = $conn->prepare("INSERT INTO insurance_policies (client_id, policy_percentage, expiration_date) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $clientId, $policyPercentage, $expirationDate);
    $stmt->execute();

    $conn->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Cliente registrado exitosamente',
        'client_id' => $clientId
    ]);
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode([
        'success' => false,
        'message' => 'Error al registrar cliente',
        'error' => $e->getMessage()
    ]);
}
?>

