<?php
require_once "db.php";
require_once "vendor/autoload.php";
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json");

$secret_key = "mi_clave_secreta";
if (!isset($_COOKIE['auth_token'])) {
    echo json_encode(["success" => false, "message" => "No autenticado"]);
    exit;
}

try {
    $decoded = JWT::decode($_COOKIE['auth_token'], new Key($secret_key, 'HS256'));
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Token inválido"]);
    exit;
}

// Obtener pacientes
$sql = "SELECT id, nombre FROM pacientes ORDER BY nombre ASC";
$result = $conn->query($sql);

$pacientes = [];
while ($row = $result->fetch_assoc()) {
    $pacientes[] = $row;
}

// 🔧 Cambiar 'pacientes' por 'patients' para que coincida con el frontend
echo json_encode(["success" => true, "patients" => $pacientes]);
