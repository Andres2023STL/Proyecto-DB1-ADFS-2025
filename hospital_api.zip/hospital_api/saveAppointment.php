<?php
require 'db.php';
require 'auth.php'; // si usas JWT para validar

$data = json_decode(file_get_contents("php://input"), true);

$doctor_id = $data['doctor_id'];
$paciente_id = $data['paciente_id'];
$fecha = $data['fecha'];
$hora = $data['hora'];
$motivo = $data['motivo'];
$asegurado = $data['asegurado'] ? 1 : 0;

$query = "INSERT INTO appointments (doctor_id, paciente_id, fecha, hora, motivo, asegurado) 
          VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($query);
$stmt->bind_param("iisssi", $doctor_id, $paciente_id, $fecha, $hora, $motivo, $asegurado);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Cita guardada"]);
} else {
    echo json_encode(["success" => false, "message" => "Error al guardar cita"]);
}
?>
