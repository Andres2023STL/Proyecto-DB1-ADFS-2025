<?php
require_once "db.php";
require_once "auth.php";

header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$user = authenticate(); // <- tu función de auth con JWT
$data = json_decode(file_get_contents("php://input"), true);

$sql = "INSERT INTO empleados_seguro (user_id, nombre, numero_empleado, departamento, area_cobertura, telefono)
        VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("isssss", $user['id'], $data['nombre'], $data['puesto'], $data['departamento'], $data['numero_empleado'], $data['telefono']);

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "message" => "Error al guardar"]);
}
