<?php
require_once "db.php";
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

try {
    // Insertar en reports
    $stmt = $conn->prepare("INSERT INTO reports (title, summary, date) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $title, $summary, $date);
    $title = "Reporte de marzo";
    $summary = "Servicios y ventas del mes de marzo";
    $date = "2025-03-31";
    $stmt->execute();
    $report_id = $stmt->insert_id;

    // Detalles
    $detalles = [
        [
            "hospital" => "Hospital Central",
            "pharmacy" => null,
            "total" => 3200.00,
            "services" => [
                ["service" => "Consulta general", "amount" => 1500.00],
                ["service" => "Cirugía menor", "amount" => 1700.00]
            ]
        ],
        [
            "hospital" => null,
            "pharmacy" => "Farmacia Saludable",
            "total" => 900.00,
            "services" => [
                ["service" => "Ibuprofeno", "amount" => 300.00],
                ["service" => "Amoxicilina", "amount" => 600.00]
            ]
        ]
    ];

    foreach ($detalles as $d) {
        $stmt2 = $conn->prepare("INSERT INTO report_details (report_id, hospital, pharmacy, total) VALUES (?, ?, ?, ?)");
        $stmt2->bind_param("isss", $report_id, $d["hospital"], $d["pharmacy"], $d["total"]);
        $stmt2->execute();
        $detail_id = $stmt2->insert_id;

        foreach ($d["services"] as $s) {
            $stmt3 = $conn->prepare("INSERT INTO report_services (detail_id, service, amount) VALUES (?, ?, ?)");
            $stmt3->bind_param("isd", $detail_id, $s["service"], $s["amount"]);
            $stmt3->execute();
        }
    }

    echo json_encode(["success" => true, "message" => "Reporte generado correctamente."]);
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Error al generar reporte", "error" => $e->getMessage()]);
}
?>
