<?php
require_once "db.php";
require_once "vendor/autoload.php";
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

$secret_key = "mi_clave_secreta";

if (!isset($_COOKIE['auth_token'])) {
    echo json_encode(["success" => false, "message" => "No autenticado"]);
    exit;
}

try {
    $decoded = JWT::decode($_COOKIE["auth_token"], new Key($secret_key, "HS256"));
    $role = $decoded->role ?? null;

    if ($role !== "empleado_seguro") {
        echo json_encode(["success" => false, "message" => "No autorizado"]);
        exit;
    }

    $stmt = $conn->prepare("SELECT * FROM medicinas ORDER BY category, subcategory");
    $stmt->execute();
    $res = $stmt->get_result();

    $medicinas = [];
    while ($row = $res->fetch_assoc()) {
        $medicinas[] = $row;
    }

    echo json_encode(["success" => true, "medicinas" => $medicinas]);
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Token inválido"]);
}
