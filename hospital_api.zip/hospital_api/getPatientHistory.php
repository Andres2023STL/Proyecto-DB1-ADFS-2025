<?php
require_once "db.php";
require_once "vendor/autoload.php";
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

// ==== CORS HEADERS ====
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json");

// ==== JWT VERIFICATION ====
$secret_key = "mi_clave_secreta";

if (!isset($_COOKIE['auth_token'])) {
    echo json_encode(["success" => false, "message" => "No autenticado"]);
    exit;
}

try {
    $decoded = JWT::decode($_COOKIE["auth_token"], new Key($secret_key, "HS256"));
    $role = $decoded->role;

    if (!in_array($role, ['doctor', 'empleado_hospital'])) {
        echo json_encode(["success" => false, "message" => "No autorizado"]);
        exit;
    }

    $doctor_id = $decoded->doctor_id ?? null;

} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Token inválido"]);
    exit;
}

// ==== QUERY DE PACIENTES ====

$patients = [];

$queryPacientes = "
    SELECT p.id, p.nombre, p.documento, p.fecha_nacimiento, p.fotografia, 
           p.tiene_seguro, p.codigo_seguro
    FROM pacientes p
";

// Si es doctor, filtra solo pacientes que ha atendido
if ($role === "doctor" && $doctor_id) {
    $queryPacientes .= " 
        INNER JOIN appointments a ON a.paciente_id = p.id 
        WHERE a.doctor_id = $doctor_id 
        GROUP BY p.id
    ";
}

$res = $conn->query($queryPacientes);

while ($row = $res->fetch_assoc()) {
    $paciente_id = $row['id'];

    // Últimas citas
    $citas = [];
    $sqlCitas = $conn->query("SELECT fecha, hora, motivo FROM appointments WHERE paciente_id = $paciente_id ORDER BY fecha DESC LIMIT 5");
    while ($cita = $sqlCitas->fetch_assoc()) {
        $citas[] = $cita;
    }

    // Última receta
    $receta = $conn->query("SELECT diagnostico, medicamento FROM prescriptions WHERE paciente_id = $paciente_id ORDER BY fecha DESC LIMIT 1")->fetch_assoc();

    $patients[] = [
        "id" => $paciente_id,
        "nombre" => $row['nombre'],
        "documento" => $row['documento'],
        "fecha_nacimiento" => $row['fecha_nacimiento'],
        "foto" => $row['fotografia'],
        "seguro" => $row['tiene_seguro'] ? "Sí" : "No",
        "codigo_seguro" => $row['codigo_seguro'],
        "ultima_visita" => $citas[0]['fecha'] ?? null,
        "diagnostico" => $receta['diagnostico'] ?? null,
        "medicamentos" => isset($receta['medicamento']) ? explode(",", $receta['medicamento']) : [],
        "citas" => $citas
    ];
}

echo json_encode(["success" => true, "patients" => $patients]);
