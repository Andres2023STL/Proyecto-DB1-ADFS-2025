<?php
require_once "db.php";
require_once "vendor/autoload.php";
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

// ==== CORS HEADERS ====
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json");

// ==== JWT VERIFICATION ====
$secret_key = "mi_clave_secreta";

if (!isset($_COOKIE['auth_token'])) {
    echo json_encode(["success" => false, "message" => "No autenticado"]);
    exit;
}

try {
    $decoded = JWT::decode($_COOKIE["auth_token"], new Key($secret_key, "HS256"));
    $role = $decoded->role;
    if (!in_array($role, ['doctor', 'empleado_hospital'])) {
        echo json_encode(["success" => false, "message" => "No autorizado"]);
        exit;
    }
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Token inválido"]);
    exit;
}

// ==== CONSULTAR PACIENTES ====
$query = "SELECT * FROM pacientes";
$res = $conn->query($query);

$patients = [];

while ($row = $res->fetch_assoc()) {
    $paciente_id = $row['id'];

    // ==== CONSULTAR CITAS ====
    $citas = [];
    $sqlCitas = $conn->query("
        SELECT fecha, hora, motivo 
        FROM appointments 
        WHERE paciente_id = $paciente_id 
        ORDER BY fecha DESC 
        LIMIT 5
    ");
    while ($cita = $sqlCitas->fetch_assoc()) {
        $citas[] = $cita;
    }

    // Última visita
    $lastVisit = $citas[0]['fecha'] ?? null;

    // ==== CONSULTAR ÚLTIMA PRESCRIPCIÓN ====
    $receta = $conn->query("
        SELECT diagnostico, medicamento 
        FROM prescriptions 
        WHERE paciente_id = $paciente_id 
        ORDER BY fecha DESC 
        LIMIT 1
    ")->fetch_assoc();

    // ==== AGREGAR PACIENTE A LA LISTA ====
    $patients[] = [
        "id" => $paciente_id,
        "name" => $row['nombre'],
        "documentId" => $row['documento'],
        "birthDate" => $row['fecha_nacimiento'],
        "photo" => $row['fotografia'],
        "insuranceNumber" => $row['codigo_seguro'],
        "insuranceCompany" => $row['tiene_seguro'] ? "Sí" : "No",
        "lastVisit" => $lastVisit,
        "diagnosis" => $receta['diagnostico'] ?? null,
        "medications" => isset($receta['medicamento']) ? explode(",", $receta['medicamento']) : [],
        "services" => $citas,
        "notes" => $receta['diagnostico'] ?? null
    ];
}

echo json_encode(["success" => true, "patients" => $patients]);
?>
