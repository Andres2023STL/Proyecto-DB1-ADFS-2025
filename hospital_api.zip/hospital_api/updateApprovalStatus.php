<?php
require_once "db.php";
require_once "vendor/autoload.php";

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

// CORS headers
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json");

$secret_key = "mi_clave_secreta";

// Validar si viene el token
if (!isset($_COOKIE['auth_token'])) {
    echo json_encode(["success" => false, "message" => "No autenticado"]);
    exit;
}

try {
    $decoded = JWT::decode($_COOKIE["auth_token"], new Key($secret_key, "HS256"));

    // Solo el rol empleado_seguro puede actualizar estado
    if ($decoded->role !== "empleado_seguro") {
        echo json_encode(["success" => false, "message" => "No autorizado"]);
        exit;
    }

    // Obtener datos del cuerpo del request
    $data = json_decode(file_get_contents("php://input"), true);

    $appointment_id = $data["appointment_id"] ?? null;
    $status = $data["status"] ?? null;
    $authorization = $data["authorization"] ?? null;
    $copago = $data["copago"] ?? null;

    if (!$appointment_id || !in_array($status, ["aprobado", "rechazado"])) {
        echo json_encode(["success" => false, "message" => "Datos incompletos o inválidos"]);
        exit;
    }

    // Determinar el valor de aprobado (1 = sí, 0 = no)
    $approved = ($status === "aprobado") ? 1 : 0;

    // Preparar consulta
    $stmt = $conn->prepare("UPDATE appointments SET aprobado = ?, autorizacion_seguro = ?, copago = ? WHERE id = ?");
    $stmt->bind_param("isdi", $approved, $authorization, $copago, $appointment_id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo json_encode(["success" => true, "message" => "Estado actualizado correctamente"]);
    } else {
        echo json_encode(["success" => false, "message" => "No se pudo actualizar el estado"]);
    }

} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Token inválido", "error" => $e->getMessage()]);
}
?>
