<?php
require_once "db.php";
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

try {
    $reports = [];
    $res = $conn->query("SELECT * FROM reports ORDER BY date DESC");

    while ($report = $res->fetch_assoc()) {
        $report_id = $report["id"];
        $details = [];

        $resDetail = $conn->query("SELECT * FROM report_details WHERE report_id = $report_id");
        while ($detail = $resDetail->fetch_assoc()) {
            $detail_id = $detail["id"];
            $services = [];

            $resServ = $conn->query("SELECT * FROM report_services WHERE detail_id = $detail_id");
            while ($srv = $resServ->fetch_assoc()) {
                $services[] = [
                    "service" => $srv["service"],
                    "amount" => $srv["amount"]
                ];
            }

            $details[] = [
                "hospital" => $detail["hospital"],
                "pharmacy" => $detail["pharmacy"],
                "total" => $detail["total"],
                "services" => $services
            ];
        }

        $reports[] = [
            "title" => $report["title"],
            "summary" => $report["summary"],
            "date" => $report["date"],
            "details" => $details
        ];
    }

    echo json_encode(["success" => true, "reports" => $reports]);
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Error al obtener reportes", "error" => $e->getMessage()]);
}
?>
