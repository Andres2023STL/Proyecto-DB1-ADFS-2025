<?php
// DEBUG: Muestra errores
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// CORS
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');

require_once "db.php";

$sql = "SELECT ic.id, ic.name, ic.document_id, ic.insurance_number, 
               ip.policy_percentage, ip.expiration_date,
               cs.id AS service_id, cs.service_name, cs.last_visit, cs.diagnosis, cs.medications, cs.notes, cs.cost, cs.copayment, cs.paid, cs.expiration_date AS service_expiration
        FROM insurance_clients ic
        LEFT JOIN insurance_policies ip ON ic.id = ip.client_id
        LEFT JOIN client_services cs ON ic.id = cs.client_id";

$result = $conn->query($sql);

$clients = [];
while ($row = $result->fetch_assoc()) {
    $clientId = $row['id'];
    if (!isset($clients[$clientId])) {
        $clients[$clientId] = [
            'id' => $clientId,
            'name' => $row['name'],
            'documentId' => $row['document_id'],
            'insuranceNumber' => $row['insurance_number'],
            'policy_percentage' => $row['policy_percentage'],
            'expiration_date' => $row['expiration_date'],
            'services' => []
        ];
    }
    if ($row['service_id']) {
        $clients[$clientId]['services'][] = [
            'id' => $row['service_id'],
            'serviceName' => $row['service_name'],
            'lastVisit' => $row['last_visit'],
            'diagnosis' => $row['diagnosis'],
            'medications' => explode(',', $row['medications']),
            'notes' => $row['notes'],
            'cost' => $row['cost'],
            'copayment' => $row['copayment'],
            'paid' => (bool)$row['paid'],
            'expirationDate' => $row['service_expiration']
        ];
    }
}

echo json_encode([
    "success" => true,
    "clients" => array_values($clients)
]);

$conn->close();
?>
