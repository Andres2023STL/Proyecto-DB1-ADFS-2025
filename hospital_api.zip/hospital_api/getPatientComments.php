<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json");

require_once "db.php";
require_once "vendor/autoload.php";
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

// Manejo de preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$secret_key = "mi_clave_secreta";

// Verificar cookie
if (!isset($_COOKIE['auth_token'])) {
    echo json_encode(["success" => false, "message" => "No autenticado"]);
    exit;
}

try {
    $decoded = JWT::decode($_COOKIE["auth_token"], new Key($secret_key, 'HS256'));
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Token inválido"]);
    exit;
}

// Consulta para obtener comentarios por paciente
$sql = "SELECT id, paciente_id, user_id, rol, comentario, parent_id, fecha 
        FROM comentarios_pacientes 
        ORDER BY fecha ASC";

$result = $conn->query($sql);
$commentsByPatient = [];

while ($row = $result->fetch_assoc()) {
    $pacienteId = $row['paciente_id'];
    if (!isset($commentsByPatient[$pacienteId])) {
        $commentsByPatient[$pacienteId] = [];
    }
    $commentsByPatient[$pacienteId][] = $row;
}

echo json_encode(["success" => true, "comments" => $commentsByPatient]);
?>
