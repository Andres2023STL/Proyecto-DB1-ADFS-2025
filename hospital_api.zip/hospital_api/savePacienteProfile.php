<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

require __DIR__ . "/vendor/autoload.php";
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
include 'db.php';

// Preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Validar cookie con JWT
$secret_key = "mi_clave_secreta";
if (!isset($_COOKIE["auth_token"])) {
    echo json_encode(["success" => false, "message" => "No autenticado"]);
    exit;
}

try {
    $decoded = JWT::decode($_COOKIE["auth_token"], new Key($secret_key, 'HS256'));
    $email = $decoded->email;

    // Obtener user_id desde el email
    $res = $conn->query("SELECT id FROM users WHERE email = '$email'");
    if ($res->num_rows === 0) {
        echo json_encode(["success" => false, "message" => "Usuario no encontrado"]);
        exit;
    }
    $user_id = $res->fetch_assoc()['id'];

    // Datos del formulario
    $data = json_decode(file_get_contents("php://input"), true);

    $nombre = $conn->real_escape_string($data['nombre'] ?? '');
    $documento = $conn->real_escape_string($data['documento'] ?? '');
    $fecha_nacimiento = $conn->real_escape_string($data['fecha_nacimiento'] ?? '');
    $telefono = $conn->real_escape_string($data['telefono'] ?? '');
    $direccion = $conn->real_escape_string($data['direccion'] ?? '');
    $foto = $conn->real_escape_string($data['foto'] ?? '');



    $tiene_seguro = isset($data['tiene_seguro']) && $data['tiene_seguro'] ? 1 : 0;
// Convierte a NULL explícitamente si es vacío
$codigo_seguro = !empty($codigo_seguro) ? $codigo_seguro : null;
$numero_carnet = !empty($numero_carnet) ? $numero_carnet : null;
$tipo_poliza = !empty($tipo_poliza) ? $tipo_poliza : null;
$fecha_expiracion = !empty($fecha_expiracion) ? $fecha_expiracion : null;

// El bind_param no puede pasar null directamente, entonces usás tipos "s" y luego seteás null
$stmt = $conn->prepare("INSERT INTO pacientes (
    user_id, nombre, documento, fecha_nacimiento, telefono, direccion, fotografia,
    tiene_seguro, codigo_seguro, numero_carnet, tipo_poliza, fecha_expiracion_poliza
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->bind_param(
    "isssssssssss",
    $user_id,
    $nombre,
    $documento,
    $fecha_nacimiento,
    $telefono,
    $direccion,
    $foto,
    $tiene_seguro,
    $codigo_seguro,
    $numero_carnet,
    $tipo_poliza,
    $fecha_expiracion
);


    if (!$stmt->execute()) {
        echo json_encode(["success" => false, "message" => "Error al guardar perfil: " . $stmt->error]);
        exit;
    }

    echo json_encode(["success" => true]);
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Error: " . $e->getMessage()]);
}
