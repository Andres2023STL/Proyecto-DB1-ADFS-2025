<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Credentials: true");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . "/db.php";
require_once __DIR__ . "/vendor/autoload.php";
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

// Verificar token JWT en cookie
$secret_key = "mi_clave_secreta";
if (!isset($_COOKIE['auth_token'])) {
    echo json_encode(["success" => false, "message" => "No autenticado"]);
    exit;
}

try {
    $decoded = JWT::decode($_COOKIE['auth_token'], new Key($secret_key, 'HS256'));
    $email = $decoded->email;

    // Obtener user_id desde el email
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows === 0) {
        echo json_encode(["success" => false, "message" => "Usuario no encontrado"]);
        exit;
    }
    $user_id = $res->fetch_assoc()['id'];

    // Leer datos JSON
    $data = json_decode(file_get_contents("php://input"), true);

    $nombre = $conn->real_escape_string($data['nombre'] ?? '');
    $puesto = $conn->real_escape_string($data['puesto'] ?? '');
    $departamento = $conn->real_escape_string($data['departamento'] ?? '');
    $numero_empleado = $conn->real_escape_string($data['numero_empleado'] ?? '');
    $telefono = $conn->real_escape_string($data['telefono'] ?? '');
    $fotografia = $conn->real_escape_string($data['fotografia'] ?? '');

    // Insertar en la tabla empleados_hospital
    $stmt = $conn->prepare("INSERT INTO empleados_hospital 
        (user_id, nombre, puesto, departamento, numero_empleado, telefono, fotografia)
        VALUES (?, ?, ?, ?, ?, ?, ?)");

    $stmt->bind_param("issssss", $user_id, $nombre, $puesto, $departamento, $numero_empleado, $telefono, $fotografia);

    if ($stmt->execute()) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "message" => "Error al guardar perfil: " . $stmt->error]);
    }

} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Error en autenticación o guardado", "error" => $e->getMessage()]);
}
