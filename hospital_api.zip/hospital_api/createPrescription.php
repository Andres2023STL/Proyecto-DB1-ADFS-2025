<?php
// ==== CABECERAS CORS (importante ponerlas ANTES de cualquier salida) ====
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json");

// ==== Manejo de preflight (OPTIONS) ====
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// ==== Mostrar errores (desarrollo) ====
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ==== Carga de dependencias ====
require_once "db.php";
require_once "vendor/autoload.php";
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

// ==== Verificar token JWT ====
$secret_key = "mi_clave_secreta";

if (!isset($_COOKIE['auth_token'])) {
    echo json_encode(["success" => false, "message" => "No autenticado"]);
    exit;
}

try {
    $decoded = JWT::decode($_COOKIE['auth_token'], new Key($secret_key, 'HS256'));
    $userId = $decoded->user_id;
    if ($decoded->role !== 'doctor') {
        echo json_encode(["success" => false, "message" => "Solo los doctores pueden crear recetas"]);
        exit;
    }
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Token inválido", "error" => $e->getMessage()]);
    exit;
}

// ==== Leer datos recibidos ====
$data = json_decode(file_get_contents("php://input"), true);

// ==== Validación de campos obligatorios ====
$required = [
    'appointment_id', 'paciente_id', 'doctor_id',
    'medicamento', 'diagnostico', 'principio_activo',
    'concentracion', 'presentacion', 'forma_farmaceutica',
    'dosis', 'frecuencia', 'duracion'
];

foreach ($required as $field) {
    if (empty($data[$field])) {
        echo json_encode(["success" => false, "message" => "Falta el campo: $field"]);
        exit;
    }
}

// ==== Variables opcionales ====
$anotaciones = $data['anotaciones'] ?? null;
$notas_especiales = $data['notas_especiales'] ?? null;
$hospital_code = "00256"; // Código fijo del hospital

// ==== Obtener datos del doctor ====
$stmt = $conn->prepare("SELECT d.id, d.colegiado, d.especialidad FROM doctors d WHERE d.user_id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    echo json_encode(["success" => false, "message" => "Doctor no encontrado"]);
    exit;
}
$doctor = $result->fetch_assoc();

// ==== Obtener datos del paciente ====
$stmt = $conn->prepare("SELECT nombre, tiene_seguro, codigo_seguro FROM pacientes WHERE id = ?");
$stmt->bind_param("i", $data['paciente_id']);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    echo json_encode(["success" => false, "message" => "Paciente no encontrado"]);
    exit;
}
$paciente = $result->fetch_assoc();

// ==== Generar código de receta ====
$receta_id = uniqid();
if (!empty($paciente['tiene_seguro']) && !empty($paciente['codigo_seguro'])) {
    $codigo_receta = "{$hospital_code}-{$paciente['codigo_seguro']}-{$receta_id}";
} else {
    $codigo_receta = "{$hospital_code}-{$receta_id}";
}

// ==== Insertar en prescriptions ====
$stmt = $conn->prepare("INSERT INTO prescriptions (
    appointment_id, doctor_id, paciente_id, fecha, codigo_receta, colegiado, especialidad,
    medicamento, principio_activo, concentracion, presentacion, forma_farmaceutica,
    dosis, frecuencia, duracion, diagnostico, anotaciones, notas_especiales
) VALUES (?, ?, ?, CURDATE(), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->bind_param(
    "iiissssssssssssss",
    $data['appointment_id'],
    $data['doctor_id'],
    $data['paciente_id'],
    $codigo_receta,
    $doctor['colegiado'],
    $doctor['especialidad'],
    $data['medicamento'],
    $data['principio_activo'],
    $data['concentracion'],
    $data['presentacion'],
    $data['forma_farmaceutica'],
    $data['dosis'],
    $data['frecuencia'],
    $data['duracion'],
    $data['diagnostico'],
    $anotaciones,
    $notas_especiales
);

// ==== Ejecutar e informar resultado ====
if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Receta guardada correctamente", "codigo_receta" => $codigo_receta]);
} else {
    echo json_encode(["success" => false, "message" => "Error al guardar receta", "error" => $conn->error]);
}
?>
