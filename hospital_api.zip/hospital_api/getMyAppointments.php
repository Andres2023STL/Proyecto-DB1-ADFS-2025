<?php
require_once "db.php";
require_once "vendor/autoload.php";
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

// ==== CORS HEADERS ====
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json");

// 🔍 Para mostrar errores si hay
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ==== JWT ====
$secret_key = "mi_clave_secreta";

if (!isset($_COOKIE['auth_token'])) {
    echo json_encode(["success" => false, "message" => "No autenticado"]);
    exit;
}

try {
    $decoded = JWT::decode($_COOKIE["auth_token"], new Key($secret_key, "HS256"));
    $role = $decoded->role ?? null;
    $user_id = $decoded->user_id ?? null;

    if ($role !== "patient") {
        echo json_encode(["success" => false, "message" => "No autorizado"]);
        exit;
    }

    // Buscar paciente vinculado al user_id
    $stmtPaciente = $conn->prepare("SELECT id FROM pacientes WHERE user_id = ? LIMIT 1");
    $stmtPaciente->bind_param("i", $user_id);
    $stmtPaciente->execute();
    $resPaciente = $stmtPaciente->get_result();
    $paciente = $resPaciente->fetch_assoc();

    if (!$paciente) {
        echo json_encode(["success" => false, "message" => "Paciente no encontrado"]);
        exit;
    }

    $paciente_id = $paciente['id'];

    // Obtener citas del paciente con nombre del doctor
    $stmt = $conn->prepare("SELECT a.id, a.fecha, a.hora, a.motivo,
                                   u.name AS doctor_name
                            FROM appointments a
                            JOIN doctors d ON a.doctor_id = d.id
                            JOIN users u ON d.user_id = u.id
                            WHERE a.paciente_id = ?
                            ORDER BY a.fecha DESC, a.hora DESC");
    $stmt->bind_param("i", $paciente_id);
    $stmt->execute();
    $res = $stmt->get_result();

    $appointments = [];
    while ($row = $res->fetch_assoc()) {
        $appointments[] = [
            "id" => $row["id"],
            "fecha" => $row["fecha"],
            "hora" => $row["hora"],
            "motivo" => $row["motivo"],
            "doctor" => $row["doctor_name"] ?? "No asignado"
        ];
    }

    echo json_encode(["success" => true, "appointments" => $appointments]);

} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Token inválido", "error" => $e->getMessage()]);
}
?>
