<?php
require_once "db.php";
require_once "vendor/autoload.php";
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json");

$secret_key = "mi_clave_secreta";

if (!isset($_COOKIE['auth_token'])) {
    echo json_encode(["success" => false, "message" => "No autenticado"]);
    exit;
}

try {
    $decoded = JWT::decode($_COOKIE["auth_token"], new Key($secret_key, "HS256"));
    $user_id = $decoded->user_id;
    $role = $decoded->role;
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Token inválido"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

$paciente_id = (int) ($data["paciente_id"] ?? 0);
$comentario = trim($data["comentario"] ?? '');
$parent_id = $data["parent_id"] ?? null;

if ($paciente_id <= 0 || empty($comentario)) {
    echo json_encode(["success" => false, "message" => "Datos incompletos"]);
    exit;
}

$stmt = $conn->prepare("INSERT INTO comentarios_pacientes (paciente_id, user_id, rol, comentario, parent_id, fecha) VALUES (?, ?, ?, ?, ?, NOW())");
$stmt->bind_param("iissi", $paciente_id, $user_id, $role, $comentario, $parent_id);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "Comentario guardado"]);
} else {
    echo json_encode(["success" => false, "message" => "Error al guardar comentario", "error" => $conn->error]);
}
