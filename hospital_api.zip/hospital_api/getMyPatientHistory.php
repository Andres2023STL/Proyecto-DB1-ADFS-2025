<?php
require_once "db.php";
require_once "vendor/autoload.php";
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

// ==== HEADERS CORS + JSON ====
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json");

// ==== ERRORES VISIBLES PARA DEBUG ====
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ==== JWT ====
$secret_key = "mi_clave_secreta";

if (!isset($_COOKIE['auth_token'])) {
    echo json_encode(["success" => false, "message" => "No autenticado"]);
    exit;
}

try {
    $decoded = JWT::decode($_COOKIE["auth_token"], new Key($secret_key, "HS256"));
    $role = $decoded->role ?? null;
    $user_id = $decoded->user_id ?? null;

    if ($role !== "patient") {
        echo json_encode(["success" => false, "message" => "No autorizado"]);
        exit;
    }

    // 🔍 Buscar el paciente vinculado al user_id
    $stmt = $conn->prepare("SELECT id, nombre, documento, fecha_nacimiento, fotografia, tiene_seguro, codigo_seguro 
                            FROM pacientes WHERE user_id = ? LIMIT 1");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $paciente = $result->fetch_assoc();

    if (!$paciente) {
        echo json_encode(["success" => false, "message" => "Paciente no encontrado"]);
        exit;
    }

    $paciente_id = $paciente['id'];

    // 🔄 Últimas citas
    $citas = [];
    $sqlCitas = $conn->prepare("SELECT fecha, hora, motivo FROM appointments WHERE paciente_id = ? ORDER BY fecha DESC LIMIT 5");
    $sqlCitas->bind_param("i", $paciente_id);
    $sqlCitas->execute();
    $resCitas = $sqlCitas->get_result();
    while ($cita = $resCitas->fetch_assoc()) {
        $citas[] = $cita;
    }

    // 🔬 Última receta
    $sqlReceta = $conn->prepare("SELECT diagnostico, medicamento FROM prescriptions WHERE paciente_id = ? ORDER BY fecha DESC LIMIT 1");
    $sqlReceta->bind_param("i", $paciente_id);
    $sqlReceta->execute();
    $receta = $sqlReceta->get_result()->fetch_assoc();

    $response = [
        "id" => $paciente_id,
        "nombre" => $paciente['nombre'],
        "documento" => $paciente['documento'],
        "fecha_nacimiento" => $paciente['fecha_nacimiento'],
        "foto" => $paciente['fotografia'],
        "seguro" => $paciente['tiene_seguro'] ? "Sí" : "No",
        "codigo_seguro" => $paciente['codigo_seguro'],
        "ultima_visita" => $citas[0]['fecha'] ?? null,
        "diagnostico" => $receta['diagnostico'] ?? null,
        "medicamentos" => isset($receta['medicamento']) ? explode(",", $receta['medicamento']) : [],
        "citas" => $citas
    ];

    echo json_encode(["success" => true, "paciente" => $response]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "message" => "Error interno", "error" => $e->getMessage()]);
}
