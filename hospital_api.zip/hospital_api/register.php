<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json");

$start = microtime(true);

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

include 'db.php';
require __DIR__ . '/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (!class_exists(PHPMailer::class)) {
    echo json_encode(["success" => false, "message" => "PHPMailer no se cargó correctamente"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);
$name = $data['name'] ?? null;
$email = $data['email'] ?? null;
$password = $data['password'] ?? null;

if (!$email || !$password || !$name) {
    echo json_encode(["success" => false, "message" => "Datos incompletos."]);
    exit;
}

$stmt = $conn->prepare("SELECT id, active FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows > 0) {
    $user = $res->fetch_assoc();
    $msg = !$user['active']
        ? "Este correo ya está registrado. Si aún no has sido activado, por favor espera a que un administrador lo revise."
        : "Este correo ya está en uso. Intenta iniciar sesión o usa otro correo.";
    echo json_encode(["success" => false, "message" => $msg]);
    exit;
}

$stmt = $conn->prepare("INSERT INTO users (name, email, password, active, created_at) VALUES (?, ?, ?, 0, NOW())");
$hashedPassword = md5($password);
$stmt->bind_param("sss", $name, $email, $hashedPassword);

if ($stmt->execute()) {
    $userId = $conn->insert_id;
    $id = $userId;
    $userQuery = $conn->prepare("SELECT name, email FROM users WHERE id = ?");
    $userQuery->bind_param("i", $id);
    $userQuery->execute();
    $userResult = $userQuery->get_result();
    $newUser = $userResult->fetch_assoc();

    echo json_encode(["success" => true, "message" => "Registro exitoso. Se enviar\u00e1n los correos."]);
	if (function_exists('fastcgi_finish_request')) {
	    if (ob_get_length()) ob_end_clean(); // 🧼 limpia salida
	    fastcgi_finish_request(); // 🚀 responde rápido al navegador
	}

    if ($newUser) {
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'sistemahospital7@gmail.com';
            $mail->Password   = 'qjdcmzttjvgcyaia';
            $mail->SMTPSecure = 'tls';
            $mail->Port       = 587;

            $mail->setFrom('sistemahospital7@gmail.com', 'Sistema Hospitalario');
            $mail->addAddress($newUser['email'], $newUser['name']);
            $mail->Subject = '¡Bienvenido al Sistema Hospitalario!';
            $mail->Body    = "Hola {$newUser['name']},\n\nGracias por registrarte. Tu cuenta será activada pronto.\n\nSaludos,\nEquipo del Hospital";
            $mail->send();

            $mail->clearAddresses();
            $admins = $conn->query("SELECT email, name FROM users WHERE role = 'admin' AND active = 1");
            while ($admin = $admins->fetch_assoc()) {
                $mail->addAddress($admin['email'], $admin['name']);
            }
            $mail->Subject = '📥 Nuevo usuario registrado';
            $mail->Body    = "Se registró un nuevo usuario:\n\nNombre: {$newUser['name']}\nCorreo: {$newUser['email']}";
            $mail->send();

        } catch (Exception $e) {
            error_log("Error al enviar correos: " . $e->getMessage());
        }
    }
} else {
    echo json_encode(["success" => false, "message" => "Error al registrar usuario."]);
}

$end = microtime(true);
$timeTaken = round($end - $start, 4);
error_log("⏱️ Tiempo total de respuesta register.php: {$timeTaken} segundos");
